using System;
using System.Text.Json;




var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var app = builder.Build();

// Configure the HTTP request pipeline.


app.MapPost("/removehold", async (HttpContext context) =>
{
    using (var reader = new StreamReader(context.Request.Body))
    {
        string requestBody = await reader.ReadToEndAsync();

        PedsHold pedsHold = PedsHold.FromJson(requestBody);

        string invoice_no = "";

        if (!string.IsNullOrEmpty(pedsHold.InvoiceNo))
        {
            invoice_no = pedsHold.InvoiceNo;
        }
        else
        {
            return "{\"status\":\"fail\", \"message\":\"InvoiceNo is empty.\"}";
        }

        PEDSDatabase myDb = new PEDSDatabase();

        if (myDb.RemoveFromHold(invoice_no))
            return "{\"status\":\"success\"}";
        else
            return "{\"status\":\"fail\"}";
    }
});

app.Run("http://+:5000");

﻿using System;
using System.Text.Json;

/// <summary>
/// Summary description for Class1
/// </summary>
public class PedsHold
{
	public string InvoiceNo { get; set; }
	
	public PedsHold()
	{
		this.InvoiceNo = "";
	}

    public static PedsHold FromJson(string json)
    {
		Logger.WriteLog(json, "PedsHold.FromJson()", "Info");
        return JsonSerializer.Deserialize<PedsHold>(json);
    }
}

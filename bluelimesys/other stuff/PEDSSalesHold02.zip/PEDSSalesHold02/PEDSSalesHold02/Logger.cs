﻿using System;

public class Logger
{
	public Logger()
	{
		
	}

    public static void WriteLog(string log, string function_name, string type)
    {
		log = "-----------\n" + DateTime.Now + "\n"+type+"\n" + function_name + "\n" + log;
		Console.WriteLine(log);
    }
}

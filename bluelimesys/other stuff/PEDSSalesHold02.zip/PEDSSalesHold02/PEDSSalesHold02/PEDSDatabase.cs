﻿using System;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text.Json;

/// <summary>
/// Summary description for Class1
/// </summary>
public class PEDSDatabase
{
	public string constr { get; set; }
    public PEDSDatabase()
	{
        this.constr = "Data Source=reception-1\\SQL2012;Initial Catalog=PEDSPOSLITE;User ID=sa;Password=lock@peds";
	}

    public bool RemoveFromHold(string invoiceNo)
	{
        Logger.WriteLog("invoiceNo:" + invoiceNo, "PEDSDatabase.RemoveFromHold()","Info");
        try
        {
            string query = "UPDATE [PEDSPOSLITE].[dbo].[HoldSales] SET [IsVoid] = 1 WHERE [InvoiceNo] = '" + invoiceNo + "' AND [IsPrinted] = 0";
            SqlConnection con = new SqlConnection(this.constr);
            con.Open();
            SqlCommand sqlcom = new SqlCommand(query, con);
            int updatedRows = sqlcom.ExecuteNonQuery();

            // Logger.WriteLog("QUERY: \n" + query + "\nupdatedRows:" + updatedRows, "PEDSDatabase.RemoveFromHold()", "Info");

            if (updatedRows == 0)
                return false;
        }
        catch (Exception ex)
        {
            Logger.WriteLog(ex.Message, "PEDSDatabase.RemoveFromHold()", "Error");
            return false;
        }
        return true;
    }
}
